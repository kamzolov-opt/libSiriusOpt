from .adagrad import *
from .adam import *
from .fastdescent import *
from .heavy_ball import *
from .triangle import *
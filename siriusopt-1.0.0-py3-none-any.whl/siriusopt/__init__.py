from .show import show
from .descent import *
from .stochastic import *
from .fast import *
from .newton import *
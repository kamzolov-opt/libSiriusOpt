import numpy as np


def bin_search(a, b, dk, xk, grad, c2):
    while b - a > 1e-6:
        c = (a + b) / 2
        if grad(xk + c * dk).T @ dk >= c2 * grad(xk).T @ dk:
            b = c
        else:
            a = c
    return b


def bin_search_ray_max(a, b, dk, xk, grad, func, c1, c2):
    c = (a + b) / 2
    if func(xk + c * dk) > func(xk) + c1 * c * grad(xk).T @ dk:
        return bin_search(a, c, dk, xk, grad, c2)
    else:
        return bin_search_ray_max(c, 2 * b, dk, xk, grad, func, c1, c2)


def l_bfgs(x0, func, grad, step, c1=0.001, c2=0.9):
    xk = x0.copy()
    n = xk.shape[0]
    dk = -grad(xk)
    res = [func(xk)]
    i = np.eye(n)
    gr_prev = grad(xk)
    for _ in range(step):
        tk = bin_search_ray_max(0, 100, dk, xk, grad, func, c1, c2)
        xk_prev = xk.copy()
        xk += tk * dk
        now_gr = grad(xk)
        sk = xk - xk_prev
        yk = now_gr - gr_prev
        vk = i - np.outer(yk, sk.T) / (yk.T @ sk)
        tmp = sk.T @ yk
        hk = tmp / (yk.T @ yk) * vk.T @ vk + (sk.T @ sk) / tmp
        dk = -hk @ now_gr
        gr_prev = now_gr
        res.append(func(xk))
    return xk, res

import numpy as np
import time


def fsaga(x0, grad, func, grad_i, L, steps):
    xk = x0.copy()
    n = x0.shape[0]
    y = [grad_i(xk, i) for i in range(n)]
    sum_y = sum(y)
    hk = 1 / (3 * L)
    res = [func(xk)]
    uk = x0
    ak = 1 / L
    a_bigk = ak
    for _ in range(steps):
        j = np.random.randint(1, n)
        sum_y -= y[j]
        gr = grad_i(xk, j)
        sum_y += gr
        ak = 1 / L * 0.5 + (1 / L ** 2 * 0.25 + ak ** 2) ** 0.5
        yk = (ak * uk + a_bigk * xk) / (a_bigk + ak)
        uk = uk - ak * grad(yk)
        xk -= hk * (gr - y[j] + sum_y / n)
        xk = (ak * uk + a_bigk * xk) / (a_bigk + ak)
        a_bigk += ak
        res.append(func(xk))
        y[j] = gr
    return xk, res

import numpy as np


def Fast_grad_Nest(x0, func, grad, L, steps):
    xk = x0.copy()
    res = [func(xk)]
    alf = 0
    yk = xk
    for i in range(steps):
        alf_prev = alf
        alf = (1 + np.sqrt(1 + 4 * alf**2)) / 2
        tet = (1 - alf_prev) / alf
        yk_prev = yk
        yk = xk - 1 / L * grad(xk)
        xk = (1 - tet) * yk + tet * yk_prev
        res.append(func(xk))
    return xk, res

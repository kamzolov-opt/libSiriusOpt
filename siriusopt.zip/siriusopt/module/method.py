def function():
    return

def selffunction():
    pass
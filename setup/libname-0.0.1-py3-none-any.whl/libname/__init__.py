from .method import function
from .module import *
import sys

_names = sys.builtin_module_names

# Note:  more names are added to __all__ later.
__all__ = ["module", "method"]

def _get_exports_list(module):
    try:
        return list(module.__all__)
    except AttributeError:
        return [n for n in dir(module) if n[0] != '_']


